const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.AUTH_DB_URI;
        if (!uri) throw new Error("AUTH_DB_URI is not defined.");
        
        await mongoose.connect(uri);
        console.log(`Auth Service MongoDB Connected to authDB`);
    } catch (error) {
        console.error(`Auth Service MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
