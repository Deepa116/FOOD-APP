const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.RESTAURANT_DB_URI;
        if (!uri) throw new Error("RESTAURANT_DB_URI is not defined.");
        
        await mongoose.connect(uri);
        console.log(`Restaurant Service MongoDB Connected to restaurantDB`);
    } catch (error) {
        console.error(`Restaurant Service MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
