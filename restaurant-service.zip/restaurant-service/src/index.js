require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');

const app = express();
app.use(express.json());

connectDB();

app.get('/health', (req, res) => {
    res.status(200).json({ service: 'Restaurant Service', status: 'UP', db: 'restaurantDB' });
});

const PORT = process.env.PORT || 3003;
app.listen(PORT, () => console.log(`Restaurant Service running on port ${PORT}`));
