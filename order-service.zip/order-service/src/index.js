require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');

const app = express();
app.use(express.json());

connectDB();

app.get('/health', (req, res) => {
    res.status(200).json({ service: 'Order Service', status: 'UP', db: 'orderDB' });
});

const PORT = process.env.PORT || 3004;
app.listen(PORT, () => console.log(`Order Service running on port ${PORT}`));
