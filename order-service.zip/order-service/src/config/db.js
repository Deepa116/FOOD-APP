const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.ORDER_DB_URI;
        if (!uri) throw new Error("ORDER_DB_URI is not defined.");
        
        await mongoose.connect(uri);
        console.log(`Order Service MongoDB Connected to orderDB`);
    } catch (error) {
        console.error(`Order Service MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
