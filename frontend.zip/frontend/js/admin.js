// Initial Mock Data
let mockUsers = [
    { id: 'U1', name: 'John Doe', email: 'john@example.com', role: 'Customer' },
    { id: 'U2', name: 'Jane Smith', email: 'jane@example.com', role: 'Admin' },
    { id: 'U3', name: 'Alice Johnson', email: 'alice@example.com', role: 'Customer' }
];

let mockRestaurants = [
    { id: 'R1', name: 'Spice Route', cuisine: 'Indian', rating: 4.8, status: 'Active' },
    { id: 'R2', name: 'Burger Joint', cuisine: 'American', rating: 4.5, status: 'Active' },
    { id: 'R3', name: 'Sushi Zen', cuisine: 'Japanese', rating: 4.9, status: 'Inactive' }
];

let mockOrders = [
    { id: 'ORD-001', customer: 'John Doe', restaurant: 'Burger Joint', amount: 24.50, status: 'Completed' },
    { id: 'ORD-002', customer: 'Alice Johnson', restaurant: 'Spice Route', amount: 45.00, status: 'Preparing' },
    { id: 'ORD-003', customer: 'Bob Wilson', restaurant: 'Sushi Zen', amount: 78.50, status: 'Delivered' },
    { id: 'ORD-004', customer: 'Emma Davis', restaurant: 'Burger Joint', amount: 15.00, status: 'Pending' }
];

// Content Elements
const body = document.querySelector('body');
const navItems = document.querySelectorAll('.nav-item');
const tabs = document.querySelectorAll('.admin-tab');
const pageTitle = document.getElementById('current-page-title');

// Initialize Dashboard
document.addEventListener('DOMContentLoaded', () => {
    // Set up tab switching
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all
            navItems.forEach(n => n.classList.remove('active'));
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked item and target tab
            item.classList.add('active');
            const targetId = item.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
            
            // Update page title
            pageTitle.innerText = item.textContent.trim();
        });
    });

    renderAll();
});

function renderAll() {
    renderStats();
    renderRecentOrders();
    renderUsers();
    renderRestaurants();
    renderOrders();
}

function getStatusBadge(status) {
    switch(status.toLowerCase()) {
        case 'active':
        case 'completed':
        case 'delivered':
            return `<span class="badge badge-success">${status}</span>`;
        case 'preparing':
        case 'pending':
            return `<span class="badge badge-warning">${status}</span>`;
        case 'inactive':
        case 'cancelled':
            return `<span class="badge badge-danger">${status}</span>`;
        default:
            return `<span class="badge badge-info">${status}</span>`;
    }
}

// Render Functions
function renderStats() {
    document.getElementById('stat-users').innerText = mockUsers.length;
    document.getElementById('stat-restaurants').innerText = mockRestaurants.length;
    document.getElementById('stat-orders').innerText = mockOrders.length;
    
    const revenue = mockOrders.reduce((sum, ord) => sum + ord.amount, 0);
    document.getElementById('stat-revenue').innerText = '$' + revenue.toFixed(2);
}

function renderRecentOrders() {
    const list = document.getElementById('recent-orders-list');
    list.innerHTML = mockOrders.slice(0, 3).map(order => `
        <tr>
            <td><strong>${order.id}</strong></td>
            <td>${order.customer}</td>
            <td>${order.restaurant}</td>
            <td>$${order.amount.toFixed(2)}</td>
            <td>${getStatusBadge(order.status)}</td>
        </tr>
    `).join('');
}

function renderUsers() {
    const list = document.getElementById('users-list');
    list.innerHTML = mockUsers.map(user => `
        <tr>
            <td><strong>${user.name}</strong></td>
            <td>${user.email}</td>
            <td><span class="badge ${user.role === 'Admin' ? 'badge-primary' : 'badge-info'}">${user.role}</span></td>
            <td>
                <button class="action-btn" onclick="alert('Edit User: ${user.name}')"><ion-icon name="create-outline"></ion-icon></button>
                <button class="action-btn delete" onclick="deleteUser('${user.id}')"><ion-icon name="trash-outline"></ion-icon></button>
            </td>
        </tr>
    `).join('');
}

function renderRestaurants() {
    const list = document.getElementById('restaurants-list');
    list.innerHTML = mockRestaurants.map(rest => `
        <tr>
            <td><strong>${rest.name}</strong></td>
            <td>${rest.cuisine}</td>
            <td>⭐ ${rest.rating}</td>
            <td>${getStatusBadge(rest.status)}</td>
            <td>
                <button class="action-btn" onclick="alert('Edit Restaurant')"><ion-icon name="create-outline"></ion-icon></button>
                <button class="action-btn delete" onclick="deleteRestaurant('${rest.id}')"><ion-icon name="trash-outline"></ion-icon></button>
            </td>
        </tr>
    `).join('');
}

function renderOrders() {
    const list = document.getElementById('orders-list');
    list.innerHTML = mockOrders.map(order => `
        <tr>
            <td><strong>${order.id}</strong></td>
            <td>${order.customer}</td>
            <td>${order.restaurant}</td>
            <td>$${order.amount.toFixed(2)}</td>
            <td>${getStatusBadge(order.status)}</td>
            <td>
                <button class="action-btn" onclick="updateOrderStatus('${order.id}')" title="Update Status"><ion-icon name="sync-outline"></ion-icon></button>
                <button class="action-btn delete" onclick="deleteOrder('${order.id}')"><ion-icon name="trash-outline"></ion-icon></button>
            </td>
        </tr>
    `).join('');
}

// Mock Actions
window.deleteUser = (id) => {
    if(confirm('Are you sure you want to delete this user?')) {
        mockUsers = mockUsers.filter(u => u.id !== id);
        renderAll();
    }
};

window.deleteRestaurant = (id) => {
    if(confirm('Are you sure you want to delete this restaurant?')) {
        mockRestaurants = mockRestaurants.filter(r => r.id !== id);
        renderAll();
    }
};

window.deleteOrder = (id) => {
    if(confirm('Are you sure you want to delete this order?')) {
        mockOrders = mockOrders.filter(o => o.id !== id);
        renderAll();
    }
};

window.updateOrderStatus = (id) => {
    const order = mockOrders.find(o => o.id === id);
    if(order) {
        const statuses = ['Pending', 'Preparing', 'Delivered', 'Completed', 'Cancelled'];
        let currentIdx = statuses.indexOf(order.status);
        order.status = statuses[(currentIdx + 1) % statuses.length];
        renderAll();
    }
};
