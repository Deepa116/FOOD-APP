// DOM Elements
const navbar = document.getElementById('navbar');
const loginBtn = document.getElementById('loginBtn');
const authModal = document.getElementById('authModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const authForm = document.getElementById('authForm');
const restaurantGrid = document.getElementById('restaurant-grid');

// Scroll Effect for Navbar
if (navbar) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

// Modal Interactions
if (loginBtn && authModal && closeModalBtn) {
    loginBtn.addEventListener('click', () => {
        authModal.classList.add('active');
    });

    closeModalBtn.addEventListener('click', () => {
        authModal.classList.remove('active');
    });

    authModal.addEventListener('click', (e) => {
        if (e.target === authModal) {
            authModal.classList.remove('active');
        }
    });
}

// Mock Auth Submit
if (authForm) {
    authForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        // Imagine this hits the auth-service API
        console.log(`Authenticating user: ${email} via auth-service/login`);
        
        // Fake success
        if (loginBtn) {
            loginBtn.textContent = email.split('@')[0];
            loginBtn.classList.remove('btn-outline');
            loginBtn.classList.add('btn-primary');
        }
        if (authModal) authModal.classList.remove('active');
        
        // Notification (could add a toast UI here)
        alert(`Successfully logged in as ${email}`);
    });
}

// Mock Restaurant Data (Simulating restaurant-service API response)
const mockRestaurants = [
    {
        id: 1,
        name: "Sushi Master",
        tags: "Japanese • Seafood",
        rating: "4.9",
        distance: "1.2 km",
        image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 2,
        name: "Burger Joint",
        tags: "American • Fast Food",
        rating: "4.7",
        distance: "2.5 km",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 3,
        name: "Spice Garden",
        tags: "Indian • Curries",
        rating: "4.8",
        distance: "3.0 km",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 4,
        name: "Pasta Paradise",
        tags: "Italian • Pasta",
        rating: "4.6",
        distance: "1.8 km",
        image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 5,
        name: "Green Bowl",
        tags: "Healthy • Salads",
        rating: "4.9",
        distance: "0.8 km",
        image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 6,
        name: "Taco Fiesta",
        tags: "Mexican • Tacos",
        rating: "4.5",
        distance: "4.1 km",
        image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
];

// Render Restaurants
function renderRestaurants() {
    if (!restaurantGrid) return;
    restaurantGrid.innerHTML = '';
    mockRestaurants.forEach(restaurant => {
        const card = document.createElement('div');
        card.className = 'restaurant-card';
        card.innerHTML = `
            <div class="card-img" style="background-image: url('${restaurant.image}')"></div>
            <div class="card-content">
                <div class="card-meta">
                    <span class="rating"><ion-icon name="star"></ion-icon> ${restaurant.rating}</span>
                    <span>${restaurant.distance}</span>
                </div>
                <h3 class="card-title">${restaurant.name}</h3>
                <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 1rem;">${restaurant.tags}</p>
                <button class="btn btn-outline" style="width: 100%; padding: 0.5rem;" onclick="window.location.href='restaurant-details.html?id=${restaurant.id}'">View Menu</button>
            </div>
        `;
        restaurantGrid.appendChild(card);
    });
}

// Global checkout function
window.placeOrder = function(itemName, price) {
    alert(`Successfully placed order for ${itemName} ($${price})! It will appear in your Orders tab soon.`);
    window.location.href = 'orders.html';
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // In a real app, we would fetch from http://localhost:3003/api/restaurants (restaurant-service)
    renderRestaurants();
});
