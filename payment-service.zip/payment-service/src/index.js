require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');

const app = express();
app.use(express.json());

connectDB();

app.get('/health', (req, res) => {
    res.status(200).json({ service: 'Payment Service', status: 'UP', db: 'paymentDB' });
});

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => console.log(`Payment Service running on port ${PORT}`));
