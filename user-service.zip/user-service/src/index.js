require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');

const app = express();
app.use(express.json());

connectDB();

app.get('/health', (req, res) => {
    res.status(200).json({ service: 'User Service', status: 'UP', db: 'userDB' });
});

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`User Service running on port ${PORT}`));
