const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.PAYMENT_DB_URI;
        if (!uri) throw new Error("PAYMENT_DB_URI is not defined.");
        
        await mongoose.connect(uri);
        console.log(`Payment Service MongoDB Connected to paymentDB`);
    } catch (error) {
        console.error(`Payment Service MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
