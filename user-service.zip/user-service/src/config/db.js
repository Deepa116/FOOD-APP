const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.USER_DB_URI;
        if (!uri) throw new Error("USER_DB_URI is not defined.");
        
        await mongoose.connect(uri);
        console.log(`User Service MongoDB Connected to userDB`);
    } catch (error) {
        console.error(`User Service MongoDB Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
